﻿using System;

namespace EAA_Task03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string _password, _try;
            int attempts = 0;
            _password = "parol";
            Console.WriteLine("Введите пароль");
            _try = Console.ReadLine();

            if (_try != _password)
            {
                attempts = 1;
                while ((_try != _password) && (attempts !=3))
                {
                    Console.WriteLine($"Пароль неверный. Осталось {3 - attempts} попыток");
                    Console.WriteLine("Введите пароль");
                    _try = Console.ReadLine();
                    attempts++;      
                }
            }
            if (_try == _password)
            {
                Console.WriteLine("Введен верный пароль");
            }
            else
                Console.WriteLine("Попытки кончились");

            Console.ReadKey();
        }
    }
}
