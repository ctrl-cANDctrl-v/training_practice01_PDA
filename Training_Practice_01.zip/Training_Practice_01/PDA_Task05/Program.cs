﻿using System;

namespace PDA_Task05
{
        class Program
        {
            static void Main(string[] args)
            {

                bool go = true, enemyTurn = true;
                int enemyStep;

                Console.CursorVisible = false;


                int[,] maze = new int[,]
                {
                {2,3,4,3,3,4,3,4,3,7},
                {1,0,1,0,0,1,0,1,0,1},
                {1,0,0,0,0,0,0,0,0,1},
                {8,3,3,3,0,1,0,1,0,1},
                {1,0,0,0,0,1,0,1,0,1},
                {8,3,0,3,3,6,0,1,0,1},
                {1,0,0,0,0,0,0,1,0,1},
                {8,3,0,3,3,3,3,6,0,1},
                {1,0,0,0,0,0,0,0,0,1},
                {5,3,3,3,3,3,0,3,3,6}

                };

                int x = 1, y = 1;
                while (go)
                {

                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    for (int i = 0; i < maze.GetLength(0); i++)
                    {
                        #region DrawMaze
                        for (int j = 0; j < maze.GetLength(1); j++)
                        {
                            if (maze[i, j] == 0) Console.Write(" ");
                            if (maze[i, j] == 1) Console.Write("║");
                            if (maze[i, j] == 2) Console.Write("╔");
                            if (maze[i, j] == 3) Console.Write("═");
                            if (maze[i, j] == 4) Console.Write("╦");
                            if (maze[i, j] == 5) Console.Write("╚");
                            if (maze[i, j] == 6) Console.Write("╝");
                            if (maze[i, j] == 7) Console.Write("╗");
                            if (maze[i, j] == 8) Console.Write("╠");

                        }
                        Console.WriteLine();
                        #endregion
                    }
                    Console.CursorLeft = x;
                    Console.CursorTop = y;

                    Console.Write("¤");
             

                    ConsoleKeyInfo ki = Console.ReadKey(true);

                    try
                    {

                        if (ki.Key == ConsoleKey.LeftArrow && maze[y, x - 1] == 0)
                        {
                            x--;
                        }
                        if (ki.Key == ConsoleKey.RightArrow && maze[y, x + 1] == 0)
                        {
                            x++;
                        }
                        if (ki.Key == ConsoleKey.UpArrow && maze[y - 1, x] == 0)
                        {
                            y--;
                        }
                        if (ki.Key == ConsoleKey.DownArrow && maze[y + 1, x] == 0)
                        {
                            y++;
                        }
                    }
                    catch (Exception e)
                    {
                        Console.SetCursorPosition(60, 10);
                        go = false;
                        Console.WriteLine("Победа");
                    }
                }
            }
        }
    }

