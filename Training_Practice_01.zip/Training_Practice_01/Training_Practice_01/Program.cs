﻿using System;

namespace Training_Practice_01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int Gold, Diamonds, DiamondsCost, Change;
            double Sep;
            bool Decline;


            Decline = true;
            Console.WriteLine("Введите количетво золота, которое у вас имеется");
            Gold = Convert.ToInt32(Console.ReadLine());
            DiamondsCost = 100;      
            Console.WriteLine("Введите сколько кристалов вы хотите купить");
            Diamonds = Convert.ToInt32(Console.ReadLine());
            while (Diamonds < 0)
            {
                Diamonds = 0;
                Console.WriteLine("Введите сколько кристалов вы хотите купить");
                Diamonds = Convert.ToInt32(Console.ReadLine());
            }
            Sep = Gold - Diamonds * DiamondsCost;
            while((Sep == 0) || (Sep > 0))
            {  
                Change = Gold - Diamonds * DiamondsCost;
                Console.WriteLine($"Купленно {Diamonds} кристаллов");
                Console.WriteLine($"Сдача равна {Change}");
                Sep = -1;
                Decline = false;
            }
            while (Decline)
            {
                Console.WriteLine($"Сделка не прошла. Невозможно купить {Diamonds} за {Gold} золота");
                Decline = false;
            }
            
            Console.ReadKey();
        }
    }
}
