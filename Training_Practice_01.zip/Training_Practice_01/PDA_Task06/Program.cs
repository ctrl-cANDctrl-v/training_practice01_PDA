﻿using System;

namespace PDA_Task06
{
    internal class Program
    {

        static void Main(string[] args)
        {
            bool Work = true;
            string[] name = new string[5], position = new string[5];
            name[0] = "Иван Иваныч";
            name[1] = "Фома Фомич";
            name[2] = "Кузьма Кузьмич";
            name[3] = "Степан Степаныч";
            name[4] = "Лука Лукич";
            position[0] = "Директор";
            position[1] = "Столяр";
            position[2] = "Плотник";
            position[3] = "Инженер";
            position[4] = "Повар";


            while (Work)
            {

                Console.WriteLine("\n Введите номер команды \n" +
                "1 - добавить досье \n" +
                "2 - вывести все досье \n" +
                "3 - удалить досье \n" +
                "4 - поиск по полному имени \n" +
                "5 - выход");
               
                bool result = Int32.TryParse(Console.ReadLine(), out int act);


                switch (act)
                {
                    case 1:
                        AddCase(ref name, ref position);
                        break;
                    case 2:
                        ShowCase(ref name, ref position);
                        break;
                    case 3:
                        DeleteCase(ref name, ref position);
                        break;
                    case 4:
                        Searching(ref name, ref position);
                        break;
                    case 5:
                        Work = false;
                        break;
                }
            }
        }


        public static void ShowCase(ref string[] name, ref string[] position)
        {
            Console.WriteLine("\n Список всех досье");

            for (int i = 0; i < name.Length; i++)
            {
                Console.WriteLine($"{i + 1} Имя: {name[i]}, Должность: {position[i]}");
            }
            Console.ReadKey();

        }
        public static void AddCase(ref string[] name, ref string[] position)
        {
            string[] newName = new string[name.Length + 1];
            string[] newPosition = new string[position.Length + 1];

            for (int i = 0; i < name.Length; i++)
            {
                newName[i] = name[i];   
                newPosition[i] = position[i];
            }

            name = newName;
            position = newPosition;

            Console.WriteLine("\n Введите Имя");        
            name[name.Length - 1] =  Console.ReadLine().ToString();
            Console.WriteLine("\n Введите Должность");     
            position[position.Length - 1] = Console.ReadLine().ToString();

            Console.ReadKey();
        }
        public static void DeleteCase(ref string[] name, ref string[] position)
        {

            string[] newName = new string[name.Length - 1];
            string[] newPosition = new string[position.Length - 1];
           
            Console.WriteLine("Введите номер досье, которое надо удалить");
               
            int delNum = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < name.Length; i++)
            {
                if (i == delNum)
                {
                    for ( i = 0; i < delNum; i++)
                    {
                        newName[i] = name[i];
                        newPosition[i] = position[i];
                    }
                    for (i = delNum; i < position.Length; i++)
                    {
                        newName[i - 1] = name[i];
                        newPosition[i - 1] = position[i];
                    }

                }
            }

            name = newName;
            position = newPosition;

            Console.ReadKey();
        }
        public static void Searching(ref string[] name, ref string[] position)
        {    
            Console.WriteLine("Введите полностью имя человека, чье досье надо найти");
            string srcName = Console.ReadLine().ToString();
            string fnd = "Досье не найдено!";

            for(int i = 0; i < name.Length; i++)
            {
                if (name[i] == srcName)
                {
                    Console.WriteLine($"{i + 1} Имя: {name[i]}, Должность: {position[i]}");
                    fnd = "Досье найдено!";
                }
            }

            Console.WriteLine(fnd);
            
        }
    }
}
