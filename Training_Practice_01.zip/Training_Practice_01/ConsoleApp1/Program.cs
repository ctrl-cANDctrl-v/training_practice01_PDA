﻿using System;

namespace EAA_Task02
{
    internal class Program
    {
        static void Main(string[] args)
        {
           string wait = "no exit";
           while (wait != "exit")
            {
                Console.WriteLine("Введите слово exit, чтобы остановить");
                wait = Console.ReadLine();
            }
            Console.ReadKey();
        }
    }
}
