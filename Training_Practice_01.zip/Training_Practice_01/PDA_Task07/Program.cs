﻿using System;
using System.Collections.Generic;

namespace PDA_Task07
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] T = new int[10];

            Console.WriteLine(" Изначальный массив");

            for (int runs = 0; runs < 10; runs++)
            {
                T[runs] = runs;
                Console.Write($" {T[runs]} ");
            }
            
            Console.WriteLine("\n\n Перемешанный массив");
          
            Shuffle(T);

            void Shuffle<T>(T[] array)
            {
                var r = new Random();
                for (int i = array.Length - 1; i > 0; i--)
                {
                    int j = r.Next(i);
                    T t = array[i];
                    array[i] = array[j];
                    array[j] = t;
                    Console.Write($" {array[i]} ");
                }
            }
            Console.ReadKey();
        }
    }
}
