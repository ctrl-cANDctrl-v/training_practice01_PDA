﻿using System;

namespace EAA_Task04
{
    internal class Program
    { 
      
        static bool Assistant = false;
        static void Main(string[] args)
        {

            int HP = 500, BossHP = 500, attack = 100, BossATK = 100, Healing = 250, act = 0, newHP = 500;
            Start();
            Console.ReadKey();
            Console.WriteLine("Битва началась и первый ход за тобой. Твоё здоровье = 500");
            while ((BossHP != 0) && (HP > 0))
            {     
                act = Convert.ToInt32(Console.ReadLine());
                if (act == 1)
                {
                    if (!Assistant)
                    {
                        Assistant = true;
                        newHP = HP - 100;
                        Console.WriteLine($"Вы взвали к древним силам и они послали вам на помощь теневого духа. Здоровье уменьшено на 100 и равно {newHP}");
                        HP = newHP;
                    }
                    else
                        Console.WriteLine("Вы уже призвали духа. Можете нанести урон боссу (Введите 2) или восстановить HP (Введите 3)");
                        int _fastAct = Convert.ToInt32(Console.ReadLine());
                        if (_fastAct == 2)
                        {
                            BossHP -= attack;
                            Console.WriteLine($"Здоровье босса равно {BossHP}");
                        }
                        if (_fastAct == 3)
                        {
                           HP += Healing;
                           Console.WriteLine($"Вы открывает портал и прыгаете туда. Ваше здоровье восстановлено на 250 и равно {HP}. Здоровье босса равно {BossHP}");
                        }
                }
                if (act == 2)
                {
                    if (Assistant)
                    {
                        BossHP -= attack;
                        Console.WriteLine($"Здоровье босса равно {BossHP}");
                    }
                    else
                    {
                        Console.WriteLine("Нет призванного духа. Можете призвать его (Введите 1) или восстановить HP (Введите 3)");
                        int _fastAct = Convert.ToInt32(Console.ReadLine());
                        if (_fastAct == 1)
                        {
                            Assistant = true;
                            newHP = HP - 100;
                            Console.WriteLine($"Вы взвали к древним силам и они послали вам на помощь теневого духа. Здоровье уменьшено на 100 и равно {newHP}. Здоровье босса равно {BossHP}");
                            HP = newHP;
                        }
                        if (_fastAct == 3)
                        {
                            HP += Healing;
                            Console.WriteLine($"Вы открывает портал и прыгаете туда. Ваше здоровье восстановлено на 250 и равно {HP}. Здоровье босса равно {BossHP}");
                        }
                    }

                }
                if (act == 3)
                {
                    HP += Healing;
                    Console.WriteLine($"Вы открывает портал и прыгаете туда. Ваше здоровье восстановлено на 250 и равно {HP}");
                }
               
                Console.WriteLine($"Здоровье игрока равно {HP}");
              
                Random ran = new Random();
                
                int nxt = ran.Next(1, 3);

                if (nxt == 1)
                {
                    BossATK = 100;
                }
                else
                {
                    BossATK = 150;
                }
                HP -= BossATK;
                Console.WriteLine($"Атака босса наносит {BossATK} урона. HP игрока равно {HP}");
            }
        }


        static void Start()
        {
            Console.WriteLine("Ты наконец добрался до босса, странник. Твоя задача - убить его. Атаки босса наносят тебе 100 (обычная атака) и 150 (сильная атака) урона \n" +
                "В твоём распоряжении есть несколько видов действий \n" +
                "1: Рашамон – призывает теневого духа для нанесения атаки (Отнимает 100 хп игроку) \n" +
                "2: Хуганзакура (Может быть выполнен только после призыва теневого духа), наносит 100 ед.урона \n" +
                "3: Межпространственный разлом – позволяет скрыться в разломе и восстановить 250 хп. Урон босса по вам не проходит \n " +
                "Нажми любую кнопку, как будешь готов");
        }
    }
}
