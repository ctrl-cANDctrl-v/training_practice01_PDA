﻿using System;
using System.Windows.Forms;

namespace ReshetoEratosphena
{
    public partial class Form1 : Form
    {

        public static int n = 0;
        int value = 0;
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {          
            In:
            try
              {
                 n = Int32.Parse(textBox2.Text);
              }
            catch (FormatException) { }

            while (n < 0)
            {
                MessageBox.Show("Введите положительно число");
                textBox2.Text = "";
                n = 0;
                goto In;
            }
            int  len = n + 1;            
            int[] nums = new int[len];
            for (int i = 0; i < len; i++)
            {
                nums[i] = i;
                textBox1.Text += " " + nums[i];
            }
            for (int i = 2; i < len; i++)
            {
                for (int j = i + 1; j < len; j++)
                {
                    if (nums[j] == 0)
                        continue;
                    if (j % i == 0)
                    {
               
                        textBox3.Text += ($"При делителе {nums[i]}, удаленно число {nums[j]}.") + Environment.NewLine;
                        nums[j] = 0;
                        continue;
                    }
                }
            }
            for (int i = 2; i < len; i++)
                if ((nums[i] != 0))
                {
                    textBox4.Text += " " + nums[i];
                    value++;
                }
        }
    }
}
